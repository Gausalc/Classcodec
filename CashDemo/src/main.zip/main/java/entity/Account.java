package entity;

import lombok.Data;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * User: GAOBO
 * Date: 2020-05-12
 * Time: 21:30
 */
@Data
public class Account {
    private Integer id;
    private String username;
    private String password;
}
